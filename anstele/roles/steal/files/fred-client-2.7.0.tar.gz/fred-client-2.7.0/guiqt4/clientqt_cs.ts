<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="cs">
<context>
    <name>FredWindow</name>
    <message>
        <location filename="" line="23"/>
        <source>street</source>
        <translation>ulice</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>Create Contact panel</source>
        <translation>Panel Vytvořit kontakt</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;country code&lt;/b&gt;</source>
        <translation>&lt;b&gt;kód země&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;contact ID&lt;/b&gt;</source>
        <translation>&lt;b&gt;kontakt ID&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;email&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>postal code</source>
        <translation type="obsolete">psč</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>value-added tax</source>
        <translation>daňový identifikátor</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>fax</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>notify email</source>
        <translation>oznámení na email</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>social security number</source>
        <translation>číslo sociálního pojištění</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>state or province</source>
        <translation>Stát nebo kraj</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>clTRID</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>number</source>
        <translation>čislo</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>type</source>
        <translation>typ</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;city&lt;/b&gt;</source>
        <translation>&lt;b&gt;město&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;name&lt;/b&gt;</source>
        <translation>&lt;b&gt;jméno&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;create_contact&lt;/h2&gt;
The EPP &quot;create&quot; command is used to create an instance of an object.
An object can be created for an indefinite period of time, or an
object can be created for a specific validity period.</source>
        <translation>&lt;h2&gt;create_contact&lt;/h2&gt;
EPP příkaz &quot;create&quot; se používá pro vytvoření instance objektu.
Objekt může být vytvořen na neučitý časový úsek nebo na přesně definované období.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>organisation name</source>
        <translation>jméno organizace</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>CZ</source>
        <translation>CZ</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>pokus</source>
        <translation>pokus</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>voice (phone number)</source>
        <translation>telefon</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>+420.123456789</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>voice</source>
        <translation>telefon</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>email</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>name</source>
        <translation>jméno</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>address</source>
        <translation>adresa</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>organisation</source>
        <translation>organizace</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>disclose</source>
        <translation>zveřejnit</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>contact</source>
        <translation>kontakt</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>Create NSSET panel</source>
        <translation>Panel Vytvořit NSSET</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;create_nsset&lt;/h2&gt;
The EPP &quot;create&quot; command is used to create an instance of an object.
An object can be created for an indefinite period of time, or an
object can be created for a specific validity period.</source>
        <translation>&lt;h2&gt;create_nsset&lt;/h2&gt;
EPP příkaz &quot;create&quot; se používá pro vytvoření instance objektu.
Objekt může být vytvořen na neučitý časový úsek nebo na přesně definované období.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;tech. contact&lt;/b&gt;</source>
        <translation>&lt;b&gt;tech. kontakt&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;dns&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>admin</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>Create Domain panel</source>
        <translation>Panel Vytvořit doménu</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;domain name&lt;/b&gt;</source>
        <translation>&lt;b&gt;doménové jméno&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;registrant&lt;/b&gt;</source>
        <translation>&lt;b&gt;registrátor&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>nsset</source>
        <translation>nsset</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>period</source>
        <translation>perioda</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;unit&lt;/b&gt;</source>
        <translation>&lt;b&gt;jednotka&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;number&lt;/b&gt;</source>
        <translation>&lt;b&gt;číslo&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>year</source>
        <translation>rok</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>month</source>
        <translation>měsíc</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>valExDate</source>
        <translation>datum expirace</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;create_domain&lt;/h2&gt;
The EPP &quot;create&quot; command is used to create an instance of an object.
An object can be created for an indefinite period of time, or an
object can be created for a specific validity period.</source>
        <translation>&lt;h2&gt;create_domain&lt;/h2&gt;
EPP příkaz &quot;create&quot; se používá pro vytvoření instance objektu.
Objekt může být vytvořen na neučitý časový úsek nebo na přesně definované období.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>(required for &lt;b&gt;enum&lt;/b&gt; domains)</source>
        <translation>(povinné pro &lt;b&gt;enum&lt;/b&gt; domény)</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>Update Contact panel</source>
        <translation>Panel Aktualizovat kontakt</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;update_contact&lt;/h2&gt;
The EPP &quot;update&quot; command is used to update an instance of an existing object.
   Names what are not included into disclose list are set to opposite value of the disclose flag value.</source>
        <translation>&lt;h2&gt;update_contact&lt;/h2&gt;
EPP příkaz &quot;update&quot; se používá pro aktualizaci hodnot instance vybraného objektu.
 Jména která nejsou uvedena v seznamu disclose, jsou nastavena na opačnou hodnotu než má disclose flag.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>technical contact</source>
        <translation>technický kontakt</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>dns name</source>
        <translation>název dns</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>Update NSSET panel</source>
        <translation>Panel Aktualizovat NSSET</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h3&gt;Remove&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;Odebrat&lt;/h3&gt;</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h3&gt;Change&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;Změnit&lt;/h3&gt;</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>pasword</source>
        <translation>heslo</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;update_nsset&lt;/h2&gt;
The EPP &quot;update&quot; command is used to update an instance of an existing object.
   Names what are not included into disclose list are set to opposite value of the disclose flag value.</source>
        <translation>&lt;h2&gt;update_nsset&lt;/h2&gt;
EPP příkaz &quot;update&quot; se používá pro aktualizaci hodnot instance vybraného objektu.
 Jména která nejsou uvedena v seznamu disclose, jsou nastavena na opačnou hodnotu než má disclose flag.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h3&gt;Add&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;Přidat&lt;/h3&gt;</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>dns name&lt;br&gt;(max 9 names)</source>
        <translation>dns názvy&lt;br&gt;(maximálně 9 názvů)</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>dns</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>value</source>
        <translation>hodnota</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>FredClient</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;Status:&lt;/b&gt; &lt;span style=&quot;color:red&quot;&gt;disconnect&lt;/span&gt;</source>
        <translation>&lt;b&gt;Stav:&lt;/b&gt; &lt;span style=&quot;color:red&quot;&gt;odpojen&lt;/span&gt;</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>E&amp;xit client</source>
        <translation>U&amp;končit klienta</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>Alt+X</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>Client to EPP server</source>
        <translation>Připojení na server</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;port&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>timeout</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;certificate&lt;/b&gt;</source>
        <translation>&lt;b&gt;certifikát&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;host&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;private key&lt;/b&gt;</source>
        <translation>&lt;b&gt;privátní klíč&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&amp;Welcome</source>
        <translation>&amp;Vítejte</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;Connect&lt;/h2&gt;
This part use to connect and disconnect to the EPP server. You need defined path to the certificates in your configuration file.</source>
        <translation>&lt;h2&gt;Připojit&lt;/h2&gt;
Tato část slouží k připojení nebo odpojení od EPP serveru.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>new password</source>
        <translation>nové heslo</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;username&lt;/b&gt;</source>
        <translation>&lt;b&gt;uživatel&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;password&lt;/b&gt;</source>
        <translation>&lt;b&gt;heslo&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>Send command</source>
        <translation>Odeslat příkaz</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;login&lt;/h2&gt;
The &quot;login&quot; command establishes an ongoing server session that preserves client identity and authorization information during the duration of the session.</source>
        <translation>&lt;h2&gt;login&lt;/h2&gt;
EPP příkaz &quot;login&quot; identifikuje uživatele a zahájí spojení s EPP serverem.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>command</source>
        <translation>příkaz</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;login&lt;/b&gt;</source>
        <translation>&lt;b&gt;login&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>code</source>
        <translation>kód</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>message</source>
        <translation>hlášení</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>data</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>response</source>
        <translation>odpověď</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>login</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;logout&lt;/h2&gt;
The EPP &quot;logout&quot; command is used to end a session with an EPP server.</source>
        <translation>&lt;h2&gt;logout&lt;/h2&gt;
EPP příkaz &quot;logout&quot; se používá pro ukončení spojení s EPP serverem.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;logout&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>logout</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>message ID</source>
        <translation>ID zprávy</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>option</source>
        <translation>parametr</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>acknowledge</source>
        <translation>potvrzení</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>request</source>
        <translation>pořadavek</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>Request for message</source>
        <comment>This option request check if is any message on the server.</comment>
        <translation>Požadavek na dodání zprávy</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>This options &lt;b&gt;requests&lt;/b&gt; server for message.</source>
        <translation>Tento parametr server &lt;b&gt;požaduje&lt;/b&gt; pro odebrání zprávy.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;poll&lt;/h2&gt; The EPP &quot;poll&quot; command is used to discover and retrieve service messages queued by a server for individual clients.</source>
        <translation>&lt;h2&gt;poll&lt;/h2&gt;
EPP příkaz &quot;poll&quot; se používá k odběru servisních zpráv pro přihlášeného uživatele a ke zjištění počtu těchto zpráv uložených ve frontě.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;poll&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>poll</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;hello&lt;/h2&gt;
The EPP &quot;hello&quot; request a &quot;greeting&quot; response message from an EPP server at any time.</source>
        <translation>&lt;h2&gt;hello&lt;/h2&gt;
EPP příkazem &quot;hello&quot; si lze kdykoliv vyžádat od serveru odpověď &quot;greeting&quot;.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;hello&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>hello</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&amp;connect</source>
        <translation>&amp;připojit</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;Contact&lt;/h2&gt;
Contact represents person. This preson can be domain owner or administrator or registrant.</source>
        <translation>&lt;h2&gt;Kontakt&lt;/h2&gt;
Kontakt představuje osobu. Ta  může být vlastník domény, administrátor nebo registrátor.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;check_contact&lt;/h2&gt;
The EPP &quot;check&quot; command is used to determine if an object can be provisioned within a repository.  It provides a hint that allows a client to anticipate the success or failure of provisioning an object using the &quot;create&quot; command as object provisioning requirements are ultimately a matter of server policy.</source>
        <translation>&lt;h2&gt;check_contact&lt;/h2&gt;
EPP Příkaz &quot;check&quot; se používá ke zjištění jestli se daný objekt v repozitáři nachází. To umožňuje řídit spouštění příkazu &quot;create&quot; a poté vyhodnotit jestli příkaz uspěl nebo ne.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;check_contact&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>check</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;info_contact&lt;/h2&gt;
The EPP &quot;info&quot; command is used to retrieve information associated
with an existing object. The elements needed to identify an object
and the type of information associated with an object are both
object-specific, so the child elements of the &lt;info&gt; command are
specified using the EPP extension framework.</source>
        <translation>&lt;h2&gt;info_contact&lt;/h2&gt;
EPP příkaz &quot;info&quot; se používá ke zjištění informací spojených s vybraným objektem. Způsob identifikace objektu a typu navrácených informací spojených s objektem závisí na konkrétním typu info příkazu a případném použití EPP extension rozšíření.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;info_contact&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>info</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;create_contact&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>create</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;update_contact&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>update</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;delete_contact&lt;/h2&gt;
The EPP &quot;delete&quot; command is used to remove an instance of an existing object.</source>
        <translation>&lt;h2&gt;delete_contact&lt;/h2&gt;
EPP příkaz &quot;delete&quot; se používá pro odebrání instance vybraného objektu.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;delete_contact&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>delete</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;transfer_contact&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>transfer</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>c&amp;ontact</source>
        <translation>k&amp;ontakt</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;Nsset&lt;/h2&gt;
Nsset is set of informations about domain name servers and their address and administrators.</source>
        <translation>&lt;h2&gt;Nsset&lt;/h2&gt;
Nsset je záznam, který obsahuje odkazy na doménové servery a jejich adresy. Dále obsahuje seznam registrátorů.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;check_nsset&lt;/h2&gt;
The EPP &quot;check&quot; command is used to determine if an object can be provisioned within a repository.  It provides a hint that allows a client to anticipate the success or failure of provisioning an object using the &quot;create&quot; command as object provisioning requirements are ultimately a matter of server policy.</source>
        <translation>&lt;h2&gt;check_nsset&lt;/h2&gt;
EPP Příkaz &quot;check&quot; se používá ke zjištění jestli se daný objekt v repozitáři nachází. To umožňuje řídit spouštění příkazu &quot;create&quot; a poté vyhodnotit jestli příkaz uspěl nebo ne.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;check_nsset&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;info_nsset&lt;/h2&gt;
The EPP &quot;info&quot; command is used to retrieve information associated
with an existing object. The elements needed to identify an object
and the type of information associated with an object are both
object-specific, so the child elements of the &lt;info&gt; command are
specified using the EPP extension framework.</source>
        <translation>&lt;h2&gt;info_nsset&lt;/h2&gt;
EPP příkaz &quot;info&quot; se používá ke zjištění informací spojených s vybraným objektem. Způsob identifikace objektu a typu navrácených informací spojených s objektem závisí na konkrétním typu info příkazu a případném použití EPP extension rozšíření.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;info_nsset&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;create_nsset&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;update_nsset&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;delete_nsset&lt;/h2&gt;
The EPP &quot;delete&quot; command is used to remove an instance of an existing object.</source>
        <translation>&lt;h2&gt;delete_nsset&lt;/h2&gt;
EPP příkaz &quot;delete&quot; se používá pro odebrání instance vybraného objektu.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;delete_nsset&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&amp;nsset</source>
        <translation>&amp;nsset</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;Domain&lt;/h2&gt;
Domain is name whitch is associates nsset and contacts.</source>
        <translation>&lt;h2&gt;Doména&lt;/h2&gt;
Doména je jméno, ke kterému se vážou kontakty a nssety.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;check_domain&lt;/h2&gt;
The EPP &quot;check&quot; command is used to determine if an object can be provisioned within a repository.  It provides a hint that allows a client to anticipate the success or failure of provisioning an object using the &quot;create&quot; command as object provisioning requirements are ultimately a matter of server policy.</source>
        <translation>&lt;h2&gt;check_domain&lt;/h2&gt;
EPP Příkaz &quot;check&quot; se používá ke zjištění jestli se daný objekt v repozitáři nachází. To umožňuje řídit spouštění příkazu &quot;create&quot; a poté vyhodnotit jestli příkaz uspěl nebo ne.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;check_domain&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;info_domain&lt;/h2&gt;
The EPP &quot;info&quot; command is used to retrieve information associated
with an existing object. The elements needed to identify an object
and the type of information associated with an object are both
object-specific, so the child elements of the &lt;info&gt; command are
specified using the EPP extension framework.</source>
        <translation>&lt;h2&gt;info_domain&lt;/h2&gt;
EPP příkaz &quot;info&quot; se používá ke zjištění informací spojených s vybraným objektem. Způsob identifikace objektu a typu navrácených informací spojených s objektem závisí na konkrétním typu info příkazu a případném použití EPP extension rozšíření.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;info_domain&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;create_domain&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;update_domain&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;delete_domain&lt;/h2&gt;
The EPP &quot;delete&quot; command is used to remove an instance of an existing object.</source>
        <translation>&lt;h2&gt;delete_domain&lt;/h2&gt;
EPP příkaz &quot;delete&quot; se používá pro odebrání instance vybraného objektu.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;delete_domain&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;transfer_domain&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>value expiration date</source>
        <translation>datum expirace</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;current expiration date&lt;/b&gt;</source>
        <translation>aktální datum expirace</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;renew_domain&lt;/h2&gt;
The EPP &quot;renew&quot; command is used to extend validity of an existing object.</source>
        <translation>&lt;h2&gt;renew_domain&lt;/h2&gt;
EPP příkaz &quot;renew&quot; se používá pro prodloužení platnosti vybraného objektu.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;renew_domain&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>renew</source>
        <translation>obnovit</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&amp;domain</source>
        <translation>&amp;doména</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>Sources</source>
        <translation>Zdroje</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&amp;Close</source>
        <translation>&amp;Zavřít</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>Alt+C</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>This document was sent to the EPP server. If is empty, it has not been sent already.</source>
        <translation>Tento dokument byl odeslán na EPP server. Pokud je okno prázdné, tak k odeslání ještě nedošlo.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>Command XML</source>
        <translation>Příkaz v XML</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>This document was received from EPP server. If is empty, it has not been received already.</source>
        <translation>Dokument, který klient obdržel od EPP serveru. Pokud je okno prázné, tak nebyl ještě doručen.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>Response XML</source>
        <translation>Odpověď v XML</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>This example was build from input. It can be used in fred_client console.</source>
        <translation>Tento příklad byl sestaven ze vstupních dat. Může být použit v řádkové konzoli.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>Command line</source>
        <translation>Příkazová řádka</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>Update domain panel</source>
        <translation>Panel Aktualizace domény</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;update_domain&lt;/h2&gt;
The EPP &quot;update&quot; command is used to update an instance of an existing object.
   Names what are not included into disclose list are set to opposite value of the disclose flag value.</source>
        <translation>&lt;h2&gt;update_domain&lt;/h2&gt;
EPP příkaz &quot;update&quot; se používá pro aktualizaci hodnot instance vybraného objektu.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>admin handle</source>
        <translation>admin identifikátor</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>registrant</source>
        <translation>registrátor</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>auth. for transfer</source>
        <translation>autorizace pro transfer</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;transfer_domain&lt;/h2&gt;
The EPP &quot;transfer&quot; command makes change in client sponsorship of an existing object. The new owner becomes registrant what called transfer command. New auhtorization info is generated automaticly after successfully transfer.</source>
        <translation>&lt;h2&gt;transfer_domain&lt;/h2&gt;
Příkaz EPP &quot;transfer&quot; provádí změnu vlastníka na existujícím objektu. Novým vlastníkem se stává registrátor, který příkaz transfer použil. Pokud byl transfer úspěšný, tak se automaticky vygeneruje nové autorizační heslo.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;transfer_contact&lt;/h2&gt;
The EPP &quot;transfer&quot; command makes change in client sponsorship of an existing object. The new owner becomes registrant what called transfer command. New auhtorization info is generated automaticly after successfully transfer.</source>
        <translation>Příkaz EPP &quot;transfer&quot; provádí změnu vlastníka na existujícím objektu. Novým vlastníkem se stává registrátor, který příkaz transfer použil. Pokud byl transfer úspěšný, tak se automaticky vygeneruje nové autorizační heslo.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>Credits</source>
        <translation>Kredity</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>System messages:</source>
        <translation>Systémová hlášení:</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>Parameters in &lt;b&gt;bold&lt;/b&gt; style are &lt;b&gt;required&lt;/b&gt;. Others are optionals.</source>
        <translation>Parametry, které jsou &lt;b&gt;tučně&lt;/b&gt; jsou &lt;b&gt;povinné&lt;/b&gt;. Ostatní parametry jsou nepovinné.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>credit info</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;credit info&lt;/h2&gt;
The EPP &quot;credit info&quot; command returns credit information.</source>
        <translation>&lt;h2&gt;credit info&lt;/h2&gt;EPP příkaz &quot;credit info&quot; zobrazí informace o kreditu.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>sendAuthInfo</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;sendauthinfo_contact&lt;/h2&gt;
The EPP &apos;sendauthinfo_contact&apos; command transmit request for send authorisation info to contact email.</source>
        <translation>&lt;h2&gt;sendauthinfo_contact&lt;/h2&gt;EPP příkaz &apos;sendauthinfo_contact&apos; předá požadavek na zaslání autorizačního hesla na email kontaktu.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;sendauthinfo_contact&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;sendauthinfo_nsset&lt;/h2&gt;
The EPP &apos;sendauthinfo_nsset&apos; command transmit request for send authorisation info to technical contact email.</source>
        <translation>&lt;h2&gt;sendauthinfo_nsset&lt;/h2&gt;EPP příkaz &apos;sendauthinfo_nsset&apos; předá požadavek na zaslání autorizačního hesla na email technického kontaktu.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;sendauthinfo_nsset&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;sendauthinfo_domain&lt;/h2&gt;
The EPP &apos;sendauthinfo_domain&apos; command transmit request for send authorisation info to registrant email.</source>
        <translation>&lt;h2&gt;sendauthinfo_domain&lt;/h2&gt;EPP příkaz &apos;sendauthinfo_domain&apos; předá požadavek na zaslání autorizačního hesla na email vlastníka domény.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;sendauthinfo_domain&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>technical test</source>
        <translation>technický test</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;technical test&lt;/h2&gt;The EPP &apos;technical_test&apos; command transmit request for technical test for particular NSSET and domain. The result of the test will be saved into the message queue from where the registrant can fetch it by poll command.</source>
        <translation>&lt;h2&gt;technický test&lt;/h2&gt;Příkaz &apos;technical_test&apos; předá požadavek na provedení technického testu pro příslušný NSSET a doménu. Po skončení testu bude výsledek uložen do zpráv, které si registrátor vybírá příkazem poll.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;NSSET ID&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>Errors log</source>
        <translation>Chybový log</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;contact ID&lt;/b&gt;&lt;br&gt;
Type one or more contact handles what you want to check. Separate names by spaces or new lines.</source>
        <translation>&lt;b&gt;kontakt ID&lt;/b&gt;&lt;br&gt;Zadejte jedno nebo více ID kontaktů (identifikátor), které chcete ověřit. Identifikátory oddělujte mezerou nebo novým řádkem.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;NSSET ID&lt;/b&gt;&lt;br&gt;
Type one or more handles what you want to check. Separate names by spaces or new lines.</source>
        <translation>&lt;b&gt;NSSET ID&lt;/b&gt;&lt;br&gt;Zadejte jedno nebo více ID NSSET (identifikátor), které chcete ověřit. Identifikátory oddělujte mezerou nebo novým řádkem.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;domain names&lt;/b&gt;&lt;br&gt;
Type one or more domain names what you want to check. Separate names by spaces or new lines.</source>
        <translation>&lt;b&gt;doménová jména&lt;/b&gt;&lt;br&gt;Zadejte jedno nebo více doménových jmen, které chcete ověřit. Jména oddělujte mezerou nebo novým řádkem.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>get results</source>
        <translation>získat seznam</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;get results&lt;/h2&gt;&lt;p&gt;Returns a data chunk from the list of the records in the server buffer. Pointer is moved to next part after every transmition. If no data received the end of list has been reached.&lt;/p&gt;&lt;p&gt;New list is generated by commands &lt;strong&gt;by&lt;/strong&gt; in &lt;i&gt;contact&lt;/i&gt;, &lt;i&gt;nsset&lt;/i&gt; and &lt;i&gt;domain&lt;/i&gt; windows.&lt;/p&gt;</source>
        <translation>&lt;h2&gt;získat seznam&lt;/h2&gt;&lt;p&gt;Vrátí část seznamu z bufferu serveru. Po každém stažení se ukazatel na serveru posune na další část. Pokud se již žádná data nevracejí, tak bylo dosaženo konce seznamu. Nový seznam se nastavuje pomocí příkazů (contact_by_all, nsset_by_all, domain_by_all, ...) nebo domains_by_contact, domains_by_nsset atd.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;get results&lt;/b&gt;</source>
        <translation>&lt;b&gt;získat seznam&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>Go to NSSET-by command.</source>
        <translation>Jít na příkaz Připravit seznam NSSETů.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>NSSETs by</source>
        <translation>NSSETy podle</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>Go to domains-by command.</source>
        <translation>Jít na příkaz Připravit seznam domén.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>domains by</source>
        <translation>domény podle</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>Go to contacts-by command.</source>
        <translation>Jít na příkaz Připravit seznam kontaktů.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>contacts by</source>
        <translation>kontakty podle</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;contacts by&lt;/b&gt;</source>
        <translation>&lt;b&gt;kontakty podle&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>Go to get_result command.</source>
        <translation>Jít na příkaz Získat seznam.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;nssets by&lt;/b&gt;</source>
        <translation>&lt;b&gt;nssety podle&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;domains by&lt;/b&gt;</source>
        <translation>&lt;b&gt;domény podle&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>VAT</source>
        <translation>IČ</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>ident</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>Welcome on the &lt;b&gt;FredClient&lt;/b&gt; GUI interface.&lt;br&gt;
Beta release 0.2.0; (Needs &lt;b&gt;Fred module&lt;/b&gt; version at least 1.5.0)</source>
        <translation>Vítejte v grafické nadstavbě programu &lt;b&gt;FredClient&lt;/b&gt;&lt;br&gt;
Beta release 0.2.0; (Vyžaduje &lt;b&gt;Fred module&lt;/b&gt; verzi minimálně 1.5.0)</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>Go to create form and fill inputs.</source>
        <translation>Jít na formulář Vytvořit a vyplnit vstupy.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>Go to update form and fill inputs.</source>
        <translation>Jít na formulář Aktualizovat a vyplnit vstupy.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>prepare list</source>
        <translation>připravit seznam</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;prepare list of contacts by&lt;/h2&gt;This command fills server buffer by list of contacts and set pointer at the beginning of the list. The list is taken in sequence by calling command &lt;strong&gt;get results&lt;/strong&gt; in &lt;i&gt;connect&lt;/i&gt; window repeatedly until any data comming.</source>
        <translation>&lt;h2&gt;připravit seznam kontaktů&lt;/h2&gt;Tento příkaz zaplní buffer na serveru seznamem kontaktů a nastaví ukazatel na začátek seznamu. Data se načítají postupně opakovaným voláním příkazu &lt;b&gt;Zísakt seznam&lt;/b&gt; dokud se vracejí nějaká data.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;prepare list of nssets by&lt;/h2&gt;This command fills server buffer by list of nssets and set pointer at the beginning of the list. The list is taken in sequence by calling command &lt;strong&gt;get results&lt;/strong&gt; in &lt;i&gt;connect&lt;/i&gt; window repeatedly until any data comming.</source>
        <translation>&lt;h2&gt;připravit seznam NSSETů&lt;/h2&gt;Tento příkaz zaplní buffer na serveru seznamem NSSETů a nastaví ukazatel na začátek seznamu. Data se načítají postupně opakovaným voláním příkazu &lt;b&gt;Zísakt seznam&lt;/b&gt; dokud se vracejí nějaká data.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;h2&gt;prepare list of domains by&lt;/h2&gt;This command fills server buffer by list of domains and set pointer at the beginning of the list. The list is taken in sequence by calling command &lt;strong&gt;get results&lt;/strong&gt; in &lt;i&gt;connect&lt;/i&gt; window repeatedly until any data comming.</source>
        <translation>&lt;h2&gt;připravit seznam domén&lt;/h2&gt;Tento příkaz zaplní buffer na serveru seznamem domén a nastaví ukazatel na začátek seznamu. Data se načítají postupně opakovaným voláním příkazu &lt;b&gt;Zísakt seznam&lt;/b&gt; dokud se vracejí nějaká data.</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>reportlevel</source>
        <translation></translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>all</source>
        <translation>všechny</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>&lt;b&gt;postal code&lt;/b&gt;</source>
        <translation>&lt;b&gt;psč&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="" line="23"/>
        <source>street (&lt;b&gt;required min. 1&lt;/b&gt;)</source>
        <translation>ulice (&lt;b&gt;povinná min. 1&lt;/b&gt;)</translation>
    </message>
</context>
</TS>
